#' @import FRACTION
#' @import testthat
#' @name binomial
#' @docType package
